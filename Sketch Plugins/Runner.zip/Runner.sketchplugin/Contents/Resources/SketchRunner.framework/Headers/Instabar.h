#import <Cocoa/Cocoa.h>
FOUNDATION_EXPORT double InstabarVersionNumber;
FOUNDATION_EXPORT const unsigned char InstabarVersionString[];
